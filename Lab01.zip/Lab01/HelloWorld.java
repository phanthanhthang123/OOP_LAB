//Phan Thanh Thang
//20225927
//2.2.1
package Lab01;
public class HelloWorld {
    public static void main(String[] args){
        System.out.println("Hello, world");
    }
} 